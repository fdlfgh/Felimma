import 'package:flutter/material.dart';
import 'package:felimma/components/horizontal_listview.dart';
import 'package:felimma/components/products.dart';
import 'package:felimma/components/pages/cart.dart';


class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: new AppBar(
        elevation: 0.0,
        title: Text('Felimma', style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.deepPurple,
        actions: <Widget>[
          new IconButton(icon: Icon(Icons.search, color:Colors.white,), onPressed: (){}),
          new IconButton(icon: Icon(Icons.shopping_cart, color:Colors.white,), onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=> new Cart()));
          })
        ],
      ),

      drawer: new Drawer(
        child: Container(color: Colors.white,
          child: new ListView(
            children: <Widget>[
              //header
              new UserAccountsDrawerHeader(
                accountName: Text('Ronald Bryan', style: TextStyle(color: Colors.black),),
                accountEmail: Text('ronald0017@gmail.com', style: TextStyle(color: Colors.black),),
                currentAccountPicture: GestureDetector(
                  child: new CircleAvatar(
                    backgroundColor: Colors.deepPurple,
                    child: Icon(Icons.person, color: Colors.white,),
                  ),
                ),
                decoration: new BoxDecoration(
                    color: Colors.white
                ),
              ),

              //body
              InkWell(
                onTap: (){},
                child: ListTile(
                  title: Text('Home'),
                  leading: Icon(Icons.home, color: Colors.deepPurple),
                ),
              ),

              InkWell(
                onTap: (){},
                child: ListTile(
                  title: Text('Profile'),
                  leading: Icon(Icons.person, color: Colors.blue),
                ),
              ),

              InkWell(
                onTap: (){},
                child: ListTile(
                  title: Text('My Orders'),
                  leading: Icon(Icons.shopping_basket, color: Colors.brown),
                ),
              ),

              InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> new Cart()));
                },
                child: ListTile(
                  title: Text('Shoping Cart'),
                  leading: Icon(Icons.shopping_cart, color: Colors.green),
                ),
              ),

              InkWell(
                onTap: (){},
                child: ListTile(
                  title: Text('Likes'),
                  leading: Icon(Icons.favorite, color: Colors.red),
                ),
              ),

              Divider(),

              InkWell(
                onTap: (){},
                child: ListTile(
                  title: Text('Settings'),
                  leading: Icon(Icons.settings),
                ),
              ),

              InkWell(
                onTap: (){},
                child: ListTile(
                  title: Text('Help'),
                  leading: Icon(Icons.help),
                ),
              ),
            ],
          ),
        ),
      ),
      body:  new Column(
          children:<Widget>[
            //padding widget
            new Padding(padding: const EdgeInsets.all(6.0),
              child: Container(
                  alignment: Alignment.centerLeft,
                  child: new Text('Welcome To Felimma!', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 40.0, color: Colors.black),)),),//CATEGORIES
            //horizontal list view
            HorizontalList(),

            new Padding(padding: const EdgeInsets.all(6.0),
              child: Container(
                  alignment: Alignment.centerLeft,
                  child: new Text('What\'s New',style: TextStyle(fontWeight: FontWeight.w800, fontSize: 28.0, color: Colors.black), )),),// RECENT

            //GRID VIEW
            Flexible(
              child: Products(),
            ),
          ]
      ),
    );
  }
}