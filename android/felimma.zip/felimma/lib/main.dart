import 'package:felimma/components/pages/login.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(
    MaterialApp(
      home: Login(),theme: new ThemeData(
        primarySwatch: Colors.brown, // Your app THEME-COLOR
      ),
    )
  );
}

