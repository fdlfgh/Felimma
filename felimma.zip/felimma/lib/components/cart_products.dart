import 'package:flutter/material.dart';

class Cart_products extends StatefulWidget {
  @override
  _Cart_productsState createState() => _Cart_productsState();
}

class _Cart_productsState extends State<Cart_products> {
  var Products_on_the_cart = [
    {
      'name':'Putu Photographer',
      'picture':'images/m2.jpg',
      'price':300000,
      'category':'Photographer',
      'duration':1,
      'service_category':'Brand Photography',
    },
    {
      'name': 'Sarah',
      'picture': 'images/w1.jpeg',
      'price': 850000,
      'category': 'Model',
      'duration':1,
      'service_category':'Brand Photography',
    },
  ];


  @override
  Widget build(BuildContext context) {
    return new ListView.builder(
      itemCount: Products_on_the_cart.length,
      itemBuilder: (context, index){
        return Single_cart_product(
          cart_product_name: Products_on_the_cart[index]['name'],
          cart_product_category:Products_on_the_cart[index]['category'],
          cart_product_duration: Products_on_the_cart[index]['duration'],
          cart_product_picture: Products_on_the_cart[index]['picture'],
          cart_product_price: Products_on_the_cart[index]['price'],
          cart_product_service_category: Products_on_the_cart[index]['service_category'],
        );
      },
    );
  }
}

class Single_cart_product extends StatelessWidget {
  final cart_product_name;
  final cart_product_picture;
  final cart_product_price;
  final cart_product_category;
  final cart_product_duration;
  final cart_product_service_category;

  Single_cart_product({
    this.cart_product_name,
    this.cart_product_picture,
    this.cart_product_price,
    this.cart_product_category,
    this.cart_product_duration,
    this.cart_product_service_category,
});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: new Image.asset(cart_product_picture),
        title: new Text(cart_product_name),
        subtitle: new Column(
          children: <Widget>[
            new Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: new Text(cart_product_category,),
                ),
                Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: new Text(cart_product_service_category,),
                ),

                new Padding(padding: const EdgeInsets.all(2.0),
                child: new Text("RP${cart_product_price}", style:
                TextStyle( color: Colors.green),
                ),)
              ],
            ),
          ],
        ),
        trailing:
        FittedBox(
          fit: BoxFit.fill,
          child:
          Column(
            children: <Widget>[
              IconButton(icon: Icon(Icons.arrow_drop_up,color: Colors.deepPurple),iconSize: 38, onPressed: () {}),
              Text('$cart_product_duration',style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
              IconButton(icon: Icon(Icons.arrow_drop_down,color: Colors.deepPurple,),iconSize: 38, onPressed: () {}),

            ],
          ),
        ),


      ),
    );
  }
}

