import 'package:flutter/material.dart';
import 'package:felimma/main.dart';
import 'package:felimma/components/pages/home.dart';


class ProductDetails extends StatefulWidget {
  final product_detail_name;
  final product_detail_new_price;
  final product_detail_old_price;
  final product_detail_picture;
  final product_detail_category;

  ProductDetails({
    this.product_detail_name,
    this.product_detail_new_price,
    this.product_detail_old_price,
    this.product_detail_picture,
    this.product_detail_category
  });

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        elevation: 0.0,
        title: InkWell(
            onTap: (){Navigator.push(context, MaterialPageRoute(builder: (context)=> new HomePage()));},
            child: Text('Felimma', style: TextStyle(color: Colors.white),)),
        backgroundColor: Colors.deepPurple,
        actions: <Widget>[
          new IconButton(icon: Icon(Icons.search, color:Colors.white,), onPressed: (){}),
        ],
      ),
      body: new ListView(
        children: <Widget>[
          new Container(
            height: 300.0,
            child: GridTile(
              child: Container(
                color: Colors.white,
                child: Image.asset(widget.product_detail_picture),
              ),
              footer: new Container(
                color: Colors.white,
                child: ListTile(
                  leading: new Text(widget.product_detail_name,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0),
                  ),
                  title: new Row (
                    children: <Widget>[
                      Expanded(
                       child: new Text("RP${widget.product_detail_old_price}",
                       style: TextStyle(color: Colors.red, decoration: TextDecoration.lineThrough),)
                      ),
                      Expanded(
                          child: new Text("RP${widget.product_detail_new_price}",
                          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green),)
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          //first button
          Row(
            children: <Widget>[
              Expanded(
                child: MaterialButton(
                  onPressed: (){
                    showDatePicker(context: null, initialDate: null, firstDate: null, lastDate: null,);
                  },
                  color: Colors.white,
                  textColor: Colors.grey,
                  elevation: 0.2,
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: new Text("Date",style: TextStyle(fontWeight: FontWeight.w800, fontSize: 11.0, color: Colors.black,),)
                      ),
                      Expanded(
                          child: new Icon(Icons.arrow_drop_down)
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: MaterialButton(
                  onPressed: (){
                    showDialog(context: context,
                    builder: (context){
                      return new AlertDialog(
                        title: new Text("Category"),
                        content: new Text("Choose the Category"),
                        actions: <Widget>[
                          new MaterialButton(onPressed: (){
                            Navigator.of(context).pop(context);
                          },
                          child: new Text("Close"),
                          )
                        ],
                      );
                    }
                    );
                  },
                  color: Colors.white,
                  textColor: Colors.grey,
                  elevation: 0.2,
                  child: Row(
                    children: <Widget>[
                      Expanded(
                          child: new Text("Category",  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 11.0, color: Colors.black,),)
                      ),
                      Expanded(
                          child: new Icon(Icons.arrow_drop_down)
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: MaterialButton(
                  onPressed: (){
                    showDialog(context: context,
                        builder: (context){
                          return new AlertDialog(
                            title: new Text("Category"),
                            content: new Text("Choose the Category"),
                            actions: <Widget>[
                              new MaterialButton(onPressed: (){
                                Navigator.of(context).pop(context);
                              },
                                child: new Text("Close"),
                              )
                            ],
                          );
                        }
                    );
                  },
                  color: Colors.white,
                  textColor: Colors.grey,
                  elevation: 0.2,
                  child: Row(
                    children: <Widget>[
                      Expanded(
                          child: new Text("Duration",style: TextStyle(fontWeight: FontWeight.w800, fontSize: 11.0, color: Colors.black,),)
                      ),
                      Expanded(
                          child: new Icon(Icons.arrow_drop_down)
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          //second button
          Row(
            children: <Widget>[
              Expanded(
                child: MaterialButton(
                  onPressed: (){
                    showDialog(context: context,
                        builder: (context){
                          return new AlertDialog(
                            title: new Text("Duration"),
                            content: new Text("Choose the Duration"),
                            actions: <Widget>[
                              new MaterialButton(onPressed: (){
                                Navigator.of(context).pop(context);
                              },
                                child: new Text("Close"),
                              )
                            ],
                          );
                        }
                    );
                  },
                  color: Colors.deepPurple,
                  textColor: Colors.white,
                  elevation: 0.2,
                  child: new Text("Rent Now"),
                ),
              ),
              //button
              new IconButton(icon: Icon(Icons.add_shopping_cart),color: Colors.deepPurple, onPressed: (){}),
              new IconButton(icon: Icon(Icons.favorite_border),color: Colors.deepPurple, onPressed: (){}),
            ],
          ),

          Divider(),
          new ListTile(
            title: new Text("Details"),
            subtitle: new Text("Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."),
          ),
          Divider(),
          new Row(
            children: <Widget>[
              Padding(padding: const EdgeInsets.fromLTRB(12.0, 5.0, 5.0, 5.0),
              child: new Text("Service Name", style: TextStyle(color: Colors.grey),),
              ),
              Padding(padding: EdgeInsets.all(5.0),
              child: new Text(widget.product_detail_name),
              ),
            ],
          ),
          new Row(
            children: <Widget>[
              Padding(padding: const EdgeInsets.fromLTRB(12.0, 5.0, 5.0, 5.0),
                child: new Text("Service Category", style: TextStyle(color: Colors.grey),),
              ),

              //phone number
              Padding(padding: EdgeInsets.all(5.0),
                child: new Text(widget.product_detail_category),
              ),
            ],
          ),
          new Row(
            children: <Widget>[
              Padding(padding: const EdgeInsets.fromLTRB(12.0, 5.0, 5.0, 5.0),
                child: new Text("Phone Number", style: TextStyle(color: Colors.grey),),
              ),

              //phone number
              Padding(padding: EdgeInsets.all(5.0),
                child: new Text("0821776668"),
              ),
            ],
          ),
          new Row(
            children: <Widget>[
              Padding(padding: const EdgeInsets.fromLTRB(12.0, 5.0, 5.0, 5.0),
                child: new Text("Address", style: TextStyle(color: Colors.grey),),
              ),

              //address
              Padding(padding: EdgeInsets.all(5.0),
                child: new Text("Jimbaran, Bali"),
              ),
            ],
          ),
          Divider(),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: new Text("Other Services", style: TextStyle( fontWeight: FontWeight.bold,),),
          ),
          //Similar Products Section
          Container(
            height: 340.0,
            child: Similar_products(),
          )
        ],
      )
    );
  }
}

class Similar_products extends StatefulWidget {
  @override
  _Similar_productsState createState() => _Similar_productsState();
}

class _Similar_productsState extends State<Similar_products> {
  var product_list = [
    {
      'name':'Stars Photographer',
      'picture':'images/c1.jpg',
      'old_price':550000,
      'price':310000,
      'category':'Photographer',
    },
    {
      'name':'Sarah',
      'picture':'images/w1.jpeg',
      'old_price':1000000,
      'price':850000,
      'category':'Model',
    },
    {
      'name':'Adrian',
      'picture':'images/m2.jpeg',
      'old_price':1100000,
      'price':890000,
      'category':'Model',
    },
    {
      'name':'Hana Beauty',
      'picture':'images/w3.jpeg',
      'old_price':1200000,
      'price':900000,
      'category':'MUA',
    },
  ];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: product_list.length,
        gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2
        ), itemBuilder: (BuildContext, int index){
      return Similar_single_prod(
        product_name: product_list[index]['name'],
        product_picture: product_list[index]['picture'],
        product_old_price: product_list[index]['old_price'],
        product_price: product_list[index]['price'],
        product_category: product_list[index]['category'],
      );
    });
  }
  }



class Similar_single_prod extends StatelessWidget {
  final product_name;
  final product_picture;
  final product_old_price;
  final product_price;
  final product_category;

  Similar_single_prod({
    this.product_name,
    this.product_picture,
    this.product_old_price,
    this.product_price,
    this.product_category
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Hero(
          tag: new Text('hero1'),
          child: Material(
            child: InkWell(
              onTap: () => Navigator.of(context).push(new MaterialPageRoute(
                //here we are passing the values
                  builder: (context) => new ProductDetails(
                    product_detail_name: product_name,
                    product_detail_new_price: product_price,
                    product_detail_old_price: product_old_price,
                    product_detail_picture: product_picture,
                    product_detail_category: product_category,
                  )
              )
              ),
              child: GridTile(
                  footer: Container(
                    color: Colors.white70,
                    child: ListTile(
                      leading: Text(product_name, style: TextStyle(fontWeight: FontWeight.bold),
                      ),

                      title: Text("",
                        style: TextStyle(fontSize: 12.0, fontWeight: FontWeight.w800, color: Colors.green
                        ), //After Price
                      ),
                      subtitle: Text("",
                        style: TextStyle(
                            fontSize: 12.0, fontWeight: FontWeight.w800, color: Colors.red, decoration: TextDecoration.lineThrough
                        ),//Price before
                      ),
                    ),
                  ),
                  child: Image.asset(product_picture,
                    fit: BoxFit.cover,)),
            ),
          )),
    );
  }
}